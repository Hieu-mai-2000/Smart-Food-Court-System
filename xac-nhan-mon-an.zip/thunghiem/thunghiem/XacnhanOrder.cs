﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace thunghiem
{
    public partial class XacnhanOrder : Form
    {
        public XacnhanOrder()
        {
            LoadStatusbar();
            InitializeComponent();
            
        }
        //thoi gian dem nguoc duoc hien ra man hinh
        StatusBarPanel downTimePanel = new StatusBarPanel();
        StatusBarPanel barPanel = new StatusBarPanel();

        decimal downTime = 0;
        
        void calculateDownTime()
        {
            //tong thoi gian
            downTime = numSecond.Value + numMinute.Value * 60 + numhour.Value * 60 * 60;

        }
        void LoadStatusbar()
        {
            StatusBar bar = new StatusBar();

            bar.ShowPanels = true;
            bar.Panels.Add(barPanel);
            bar.Panels.Add(downTimePanel);

            downTimePanel.Text = "";
            barPanel.Text = "wating..";
            this.Controls.Add(bar);
        }
        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown box = sender as NumericUpDown;

            if(box.Value >= 60)
            {
                numMinute.Value++;
                box.Value = 0;
            }
        }

        private void numMinute_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown box = sender as NumericUpDown;

            if (box.Value >= 60)
            {
                numhour.Value++;
                box.Value = 0;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            downTime--;
            downTimePanel.Text = downTime.ToString();
            if(downTime == 0)
            {
                MessageBox.Show("thoi gian da het");
                this.Hide();
                CheckOrder xem = new CheckOrder();
                xem.Show();
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //"thiet lap" thoi gian se duoc tinh
            //va hien chu bat dau o cuoi khung
             calculateDownTime();
             timer1.Start();
             barPanel.Text = "Star..";
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Hide();
            CheckOrder check = new CheckOrder();
            check.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //"hoan thanh" se gui thong bao va mo lai cua so xac nhan mon an
            //dong thoi dong cua so hien tai
            MessageBox.Show("thong bao da duoc gui");
            this.Hide();
            CheckOrder xem = new CheckOrder();
            xem.Show();
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace thunghiem
{
    public partial class CheckOrder : Form
    {
        public CheckOrder()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //khi nhan vao xem hang se chuyen den man hinh tiep theo la xem chi tiet don hang
            this.Hide();
            xemdonhang xem = new xemdonhang();
            xem.Show();
            this.Close();//dong thoi dong cua so hien tai

            //get close nothingtodo here
            //Visible = false;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void CheckOrder_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Hide();
             xacnhan giao = new xacnhan();
            giao.Show();
            this.Close();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //khi nhan vao de hoan thanh thi cac nut "nhan de hoan thanh" va "huy mon" se bi vo hieu hoa
            huymon1.Enabled = false;
            nhandehoanthanh1.Enabled = false;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //khi nhan vao de huy mon thi cac nut "nhan de hoan thanh" va "huy mon" se bi vo hieu hoa
            huymon1.Enabled = false;
            nhandehoanthanh1.Enabled = false;
        }
        //moi chi xong phan List_Order_ cho don hang thu 1 thoi :(
    }
}

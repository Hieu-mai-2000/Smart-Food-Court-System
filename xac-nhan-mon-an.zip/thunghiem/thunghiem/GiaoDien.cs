﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace thunghiem
{
    public partial class xacnhan : Form
    {
        public xacnhan()
        {
            InitializeComponent();
        }

        private void click(object sender, MouseEventArgs e)
        {
            //khi nhan vao "xac nhan mon" thi se hien khung cua so moi la "kiem tra don hang"
            //dong thoi cua so hien tai se bi dong
            this.Hide();//cach close window
            CheckOrder check = new CheckOrder();
            check.ShowDialog();
            this.Close();
            //get close nothingtodo here
            //Visible = false;
        }
        //phan danh sach mon an van chua duoc thuc hien
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace thunghiem
{
    public partial class DangNhap : Form
    {
        public DangNhap()
        {
            InitializeComponent();
        }

        private void xacNhanDonHangToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this.Hide();xacnhan
             xacnhan f = new xacnhan();
            f.Show();
            //this.Close();
            //get close nothingtodo here
            Visible = false;
         
          //  Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user = "dangnhap";//tai khoan dang nhap
            string pass = "matkhau";//tai khoan mat khau
            if (user.Equals(txtdangnhap.Text) && pass.Equals(txtpass.Text))
            {
                MessageBox.Show("Dang nhap thanh cong");
                xacnhan xac = new xacnhan();//di qua giao dien
                xac.Show();//hien len giao dien

                //get close nothingtodo here
                Visible = false;

            }
            else
                MessageBox.Show("Sai tai khoan hoac mat khau");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //nut nhan de thoat
            this.Close();
        }
    }
}
